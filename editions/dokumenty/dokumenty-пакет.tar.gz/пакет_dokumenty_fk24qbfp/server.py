#!/usr/bin/env python3
"""Документы — читалка md-файлов для стола Extella.

Зачем. Md-файлы (записи, отчёты, GTM-документы) живут в папках и читаются
кому как придётся. Это окно показывает их в одном месте и умеет отправлять
строки документа задачами в «Задачи и календарь» (tududi).

Устройство по канону кабинета:
  * слушает только 127.0.0.1 — сервер, доступный по сети, отдаёт папки любому рядом;
  * файлы открываются ТОЛЬКО для чтения, записи в них нет ни одним путём;
  * токен tududi живёт здесь, на сервере, и в страницу не попадает никогда;
  * состояние окна лежит файлом рядом (state.json) — чистка браузера его не трогает.

Запуск:  python3 server.py --порт 34796
"""

import argparse
import json
import pathlib
import time
import urllib.request
import urllib.error
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ПАПКА = pathlib.Path(__file__).resolve().parent
ДОМ = pathlib.Path.home()

# Где искать md-файлы. Править список — в config.json рядом с сервером.
КОРНИ_ПО_УМОЛЧАНИЮ = [
    "~/Extella Claude Bridge",
    "~/extella-cabinet",
    "~/Documents/Extella",
]
ИСКЛЮЧЁННЫЕ_ПАПКИ = {"node_modules", ".git", "__pycache__", "venv", ".venv",
                     "dist", "build", "apps", "docker",
                     "chat_archive", "chat_archive_raw"}
ГЛУБИНА = 4

# «Задачи и календарь»: контейнер tududi напрямую — прокси кабинета режет POST.
ЗАДАЧИ_АДРЕС = "http://127.0.0.1:44789"
ТОКЕН_ФАЙЛ = ДОМ / "extella-cabinet/docker/tududi/токен_api"
ЗАДАЧИ_ОКНО = "http://127.0.0.1:34789"   # что открыть человеку

СОСТОЯНИЕ_ФАЙЛ = ПАПКА / "state.json"


def корни() -> list[pathlib.Path]:
    конфиг = ПАПКА / "config.json"
    пути = КОРНИ_ПО_УМОЛЧАНИЮ
    if конфиг.exists():
        try:
            пути = json.loads(конфиг.read_text())["roots"]
        except Exception:
            pass  # сломанный конфиг не должен убивать окно — работаем с умолчанием
    итог = []
    for п in пути:
        р = pathlib.Path(п).expanduser().resolve()
        if р.exists():
            итог.append(р)
    return итог


def скан() -> list[dict]:
    файлы = []
    for номер, корень in enumerate(корни()):
        for путь in корень.rglob("*.md"):
            try:
                отн = путь.relative_to(корень)
            except ValueError:
                continue
            if len(отн.parts) > ГЛУБИНА:
                continue
            if any(ч in ИСКЛЮЧЁННЫЕ_ПАПКИ for ч in отн.parts[:-1]):
                continue
            try:
                ст = путь.stat()
            except OSError:
                continue
            файлы.append({
                "id": f"{номер}:{отн}",
                "name": путь.stem,
                "folder": str(pathlib.Path(корень.name) / отн.parent) if str(отн.parent) != "." else корень.name,
                "mtime": int(ст.st_mtime),
                "size": ст.st_size,
            })
    файлы.sort(key=lambda ф: -ф["mtime"])
    return файлы


def прочитать(ид: str) -> dict | None:
    """Путь собирается только из известного корня — наружу не выйти."""
    try:
        номер, отн = ид.split(":", 1)
        корень = корни()[int(номер)]
    except (ValueError, IndexError):
        return None
    путь = (корень / отн).resolve()
    if not str(путь).startswith(str(корень)) or путь.suffix != ".md" or not путь.is_file():
        return None
    return {"id": ид, "name": путь.stem, "path": str(путь),
            "mtime": int(путь.stat().st_mtime),
            "text": путь.read_text(errors="replace")}


# Загрузка. Приложение читает только .md — принимать другое значило бы класть
# на диск файл, который человек потом не увидит в этом же окне.
РАСШИРЕНИЯ = {".md", ".markdown", ".txt"}
ПРЕДЕЛ_РАЗМЕРА = 5 * 1024 * 1024          # md крупнее — это уже не документ
ПАПКА_ПО_УМОЛЧАНИЮ = "Входящие"


def безопасное_имя_файла(имя: str) -> str:
    """Имя файла, которым нельзя выйти из папки и нельзя перезаписать чужое.

    Имя приходит от человека — а значит, может содержать «../», слэши и
    служебные знаки. Разделители режем, точки в начале убираем: файл должен
    лечь ровно туда, куда человек его бросил, и никуда больше.
    """
    имя = (имя or "").strip().replace("\\", "/").split("/")[-1]
    имя = "".join(з for з in имя if з not in '<>:"|?*\0').strip(". ")
    основа, точка, расш = имя.rpartition(".")
    if not точка:
        основа, расш = имя, "md"
    return (основа[:120] or "документ") + "." + (расш[:12] or "md")


def положить(имя: str, текст: str, папка: str = "") -> dict:
    """Положить документ в дерево. Возвращает id — тот же, что у скана."""
    # ПОДОЗРИТЕЛЬНОЕ ИМЯ — ОТКАЗ, А НЕ ТИХАЯ ЧИСТКА. Очистка имени и так не
    # выпускает файл за пределы папки документов, и для безопасности этого
    # хватает. Но «../../взлом.md», молча превращённый во «взлом.md» и
    # принятый как успех, — плохой ответ: у человека таких имён не бывает, а
    # тот, кто их прислал, должен получить прямой отказ, а не переименование
    # втихую (замер 23.08.2026: файл принимался и ложился во «Входящие»).
    if any(з in (имя or "") for з in ("..", "/", "\\")):
        return {"ok": False, "почему": "в имени файла есть путь — так нельзя: "
                                       "имя должно быть просто именем"}
    if ".." in (папка or ""):
        return {"ok": False, "почему": "папка ведёт наружу дерева документов"}
    расширение = pathlib.Path(безопасное_имя_файла(имя)).suffix.lower()
    if расширение not in РАСШИРЕНИЯ:
        return {"ok": False, "почему": f"«{расширение}» это окно не показывает: "
                f"принимаются {', '.join(sorted(РАСШИРЕНИЯ))}"}
    if len(текст.encode("utf-8")) > ПРЕДЕЛ_РАЗМЕРА:
        return {"ok": False, "почему": "файл больше 5 МБ — это уже не документ"}
    список = корни()
    if not список:
        return {"ok": False, "почему": "ни одной папки документов не найдено"}

    # Папка приходит из дерева окна: «Extella Claude Bridge/gtm». Первый
    # сегмент — имя корня; остальное — путь внутри него. Не нашли корень —
    # кладём в «Входящие» первого, но НЕ угадываем похожий: чужая папка тем и
    # опасна, что выглядит правильной.
    корень, внутри = список[0], ПАПКА_ПО_УМОЛЧАНИЮ
    части = [ч for ч in (папка or "").split("/") if ч and ч != ".."]
    if части:
        for н, к in enumerate(список):
            if к.name == части[0]:
                корень, внутри = к, "/".join(части[1:])
                break
    цель = (корень / внутри).resolve() if внутри else корень.resolve()
    if not str(цель).startswith(str(корень.resolve())):
        return {"ok": False, "почему": "путь ведёт наружу папки документов"}
    цель.mkdir(parents=True, exist_ok=True)

    файл = цель / безопасное_имя_файла(имя)
    # СУЩЕСТВУЮЩЕЕ НЕ ПЕРЕЗАПИСЫВАЕМ. Человек бросает файл, не зная, что там
    # уже лежит одноимённый; молча затереть чужую работу — худшее, что может
    # сделать загрузка.
    if файл.exists():
        основа, расш = файл.stem, файл.suffix
        н = 2
        while (цель / f"{основа} ({н}){расш}").exists():
            н += 1
        файл = цель / f"{основа} ({н}){расш}"
    try:
        файл.write_text(текст, encoding="utf-8")
    except OSError as е:
        return {"ok": False, "почему": f"не записалось: {е}"}
    номер = список.index(корень)
    отн = файл.relative_to(корень)
    return {"ok": True, "id": f"{номер}:{отн}", "имя": файл.name,
            "куда": str(pathlib.Path(корень.name) / отн.parent)}


def токен() -> str | None:
    try:
        return ТОКЕН_ФАЙЛ.read_text().strip()
    except OSError:
        return None


def задачи_живы() -> bool:
    try:
        with urllib.request.urlopen(ЗАДАЧИ_АДРЕС + "/api/v1/health", timeout=2):
            return True
    except Exception:
        return False


def создать_задачу(название: str, заметка: str) -> dict:
    т = токен()
    if not т:
        return {"ok": False, "почему": "нет_токена"}
    тело = json.dumps({"name": название[:250], "note": заметка, "status": 0}).encode()
    запрос = urllib.request.Request(
        ЗАДАЧИ_АДРЕС + "/api/v1/task", data=тело, method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + т})
    try:
        with urllib.request.urlopen(запрос, timeout=6) as ответ:
            данные = json.loads(ответ.read())
            return {"ok": True, "uid": данные.get("uid"), "открыть": ЗАДАЧИ_ОКНО}
    except urllib.error.URLError:
        return {"ok": False, "почему": "недоступно"}
    except Exception:
        return {"ok": False, "почему": "отказ"}


class Обработчик(BaseHTTPRequestHandler):
    # HTTP/1.1 с keep-alive: окно ОС на HTTP/1.0 иногда рвало соединение до
    # отрисовки («The site didn't render», замер 21.08.2026). Content-Length
    # выставлен на каждом ответе — без него 1.1 подвесил бы соединение.
    protocol_version = "HTTP/1.1"
    # Окно ОС открывает страницу в песочнице без общего происхождения (origin
    # «null»), поэтому без этих заголовков её же собственные запросы к этому
    # серверу режутся браузером. Сервер слушает только 127.0.0.1 — наружу
    # заголовки ничего не открывают.
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def _json(self, данные, код=200):
        тело = json.dumps(данные, ensure_ascii=False).encode()
        self.send_response(код)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(тело)))
        self.end_headers()
        self.wfile.write(тело)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            тело = (ПАПКА / "index.html").read_bytes()
            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(тело)))
            self.end_headers()
            self.wfile.write(тело)
        elif self.path in ("/favicon.ico", "/favicon.png", "/icon.png"):
            ф = ПАПКА / "icon.png"
            if ф.exists():
                тело = ф.read_bytes()
                self.send_response(200)
                self._cors()
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(тело)))
                self.end_headers()
                self.wfile.write(тело)
            else:
                self._json({"error": "иконки нет"}, 404)
        elif self.path == "/api/files":
            self._json({"files": скан()})
        elif self.path.startswith("/api/file?id="):
            ид = urllib.parse.unquote(self.path.split("id=", 1)[1])
            данные = прочитать(ид)
            self._json(данные if данные else {"error": "не найден"}, 200 if данные else 404)
        elif self.path == "/api/health":
            self._json({"задачи": задачи_живы()})
        elif self.path == "/api/state":
            try:
                self._json(json.loads(СОСТОЯНИЕ_ФАЙЛ.read_text()))
            except Exception:
                self._json({})
        else:
            self._json({"error": "нет такого пути"}, 404)

    def do_POST(self):
        длина = int(self.headers.get("Content-Length", 0))
        try:
            тело = json.loads(self.rfile.read(длина) or b"{}")
        except json.JSONDecodeError:
            return self._json({"ok": False, "почему": "плохой запрос"}, 400)
        if self.path == "/api/task":
            название = (тело.get("title") or "").strip()
            if not название:
                return self._json({"ok": False, "почему": "пустая задача"}, 400)
            заметка = (тело.get("note") or "").strip()
            источник = (тело.get("source") or "").strip()
            if источник:
                заметка = (заметка + "\n\n" if заметка else "") + "Источник: " + источник + " · отправлено из окна «Документы»"
            self._json(создать_задачу(название, заметка))
        elif self.path == "/api/upload":
            итог = положить(тело.get("имя") or тело.get("name") or "",
                            тело.get("текст") or тело.get("text") or "",
                            тело.get("папка") or тело.get("folder") or "")
            self._json(итог, 200 if итог.get("ok") else 400)
        elif self.path == "/api/state":
            СОСТОЯНИЕ_ФАЙЛ.write_text(json.dumps(тело, ensure_ascii=False))
            self._json({"ok": True})
        else:
            self._json({"error": "нет такого пути"}, 404)

    def log_message(self, fmt, *args):
        print(time.strftime("%H:%M:%S"), fmt % args)


def самопроверка() -> int:
    """Готов / не готов и что именно. Список проверяемого — ИЗ интерфейса (§4.7)."""
    import re
    провалы = []
    страница_ф = ПАПКА / "index.html"
    if not страница_ф.exists():
        print("НЕ ГОТОВ: нет index.html — окну нечего отдавать")
        return 1
    исходник = pathlib.Path(__file__).read_text()
    нужные = sorted(set(re.findall(r'fetch\("(/api/[a-z_]+)', страница_ф.read_text())))
    # Граница слова обязательна: короткий путь иначе находится подстрокой
    # длинного (file внутри files), и пропавший маршрут остаётся зелёным.
    # Литеральных путей в комментариях не писать — проверка найдёт их здесь.
    нет = [п for п in нужные if not re.search(re.escape(п) + r"(?![a-z_])", исходник)]
    if нет:
        провалы.append("интерфейс зовёт пути, которых нет в сервере: " + ", ".join(нет))
    if not (ПАПКА / "icon.png").exists():
        провалы.append("нет icon.png — плитка и фавикон останутся пустыми")
    if not корни():
        провалы.append("ни один корень из config.json не существует — список файлов будет пуст")
    if not токен():
        провалы.append("не читается токен tududi — отправка в задачи откажет "
                       f"(ожидается {ТОКЕН_ФАЙЛ})")
    if провалы:
        print("НЕ ГОТОВ:", "; ".join(провалы))
        return 1
    print(f"ГОТОВ: пути интерфейса на месте ({', '.join(нужные)}), иконка есть, "
          f"корней: {len(корни())}, токен задач читается")
    return 0


if __name__ == "__main__":
    р = argparse.ArgumentParser()
    р.add_argument("--порт", type=int, default=34796)
    р.add_argument("--selftest", action="store_true")
    а = р.parse_args()
    if а.selftest:
        raise SystemExit(самопроверка())
    print(f"Документы: http://127.0.0.1:{а.порт} · корни: {[str(k) for k in корни()]}")
    ThreadingHTTPServer(("127.0.0.1", а.порт), Обработчик).serve_forever()
